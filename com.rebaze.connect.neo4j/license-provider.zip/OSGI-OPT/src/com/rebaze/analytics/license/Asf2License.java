package com.rebaze.analytics.license;

import com.rebaze.analytics.license.provider.License;

public class Asf2License extends License {
	public Asf2License(String s) {
		super(s);
	}
	
	public final String name = "Apache Software License 2.0";
}
