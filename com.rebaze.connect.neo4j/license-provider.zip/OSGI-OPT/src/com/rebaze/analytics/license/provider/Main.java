package com.rebaze.analytics.license.provider;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;
import java.util.jar.Manifest;

import org.osgi.dto.DTO;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rebaze.analytics.license.Asf2License;
import com.rebaze.analytics.license.BSD2License;
import com.rebaze.analytics.license.BSD3License;
import com.rebaze.analytics.license.UnknownLicense;


public class Main {
	
    Gson gson = new GsonBuilder().setPrettyPrinting().create();

	private Map<String,LicensedItem> map = new HashMap<>();
	
	class LicensedItem extends DTO {
		public String name;
		public String checksum;
		public License license;
	}
	
	class LicensedObject extends DTO {
		public String name;
		public Collection<LicensedItem> dependencies;
	}
	
	
	
	public static void main(String... args) throws Exception {
		File input = new File(args[0]);
		Properties p = new Properties();

		if (args.length > 1) {
			File props = new File(args[1]);
			p.load(new FileInputStream(props));
		}
		Main main = new Main();
		
		main.analyze(input.toURI(),p);
	}

	private void analyze(URI input, Properties p) throws Exception {
		try (JarInputStream fis = new JarInputStream(input.toURL().openStream())) {
			 buildIndex(input.toASCIIString(), fis, p);
		} 
		try (JarInputStream fis = new JarInputStream(input.toURL().openStream())) {
			 analyzeLicenses(input.toASCIIString(), fis, p);
		} 
		
		for (LicensedItem item : map.values()) {
			//System.out.println(item);
		}
		LicensedObject lic = new LicensedObject();
		lic.name = input.toASCIIString();
		lic.dependencies = map.values();
		System.out.println(gson.toJson(lic));
		
	}
	
	private void buildIndex( String name, JarInputStream fis, Properties p ) throws Exception {
		JarEntry entry = null;		
		while ((entry = fis.getNextJarEntry()) != null) {
			if (entry.getName().endsWith(".jar")) {
				
				String checksum = readFully(entry, fis);		
				LicensedItem item = new LicensedItem();
				item.checksum = checksum;
				item.name = "" + entry.getName();

				map.put(entry.getName(), item);
			}
		}
		
	}
	
	public String readFully( JarEntry entry, final InputStream is ) throws Exception
    {
	    MessageDigest digest = MessageDigest.getInstance("SHA-1");

        byte[] bytes = new byte[1024];
        int numRead = 0;
        long total = 0L;
        while ( ( numRead = is.read( bytes ) ) >= 0 )
        {
        	total +=numRead;
        	digest.update( Arrays.copyOf( bytes, numRead ) );
        }
        //System.out.println("Read: " + total + " entry: " + entry.getSize() + " (name: "+entry.getName()+")");
        return convertToHex(digest.digest());
    }

	private void analyzeLicenses( String name, JarInputStream fis, Properties p ) throws IOException, URISyntaxException {

		JarEntry entry = null;

		while ((entry = fis.getNextJarEntry()) != null) {
			//System.out.println(name + ":" + entry.getName());
			if (entry.getName().endsWith(".jar")) {
				JarInputStream sub = new JarInputStream(fis);
				
				analyzeLicenses(entry.getName(),sub,p);
				
			} else if (entry.getName().equals("META-INF/MANIFEST.MF")) {
				//JarInputStream sub = new JarInputStream(fis);
				//analyze(name + "/" + entry.getName(),sub,p);
				
			}
		}
		LicensedItem item = map.get(name);

		Manifest mf = fis.getManifest();

		if (mf != null) {
			String bsn = mf.getMainAttributes().getValue("Bundle-SymbolicName");
			String license = mf.getMainAttributes().getValue("Bundle-License");
			//System.out.println("+ " + name + " --> " + bsn + " --> " + license);

			if (license != null && item != null) {
				if (license.contains("http://www.apache.org/licenses/LICENSE-2.0") || license.contains("pache2") || license.contains("pache-2")) {
					item.license = new Asf2License(license);
				} else if (license.contains("BSD-3")) {
					item.license = new BSD3License(license);
				} else if (license.contains("BSD-2")) {
					item.license = new BSD2License(license);
				}else {
					item.license = new UnknownLicense(license);
				}
			}

			if (item != null) {
				// find from props:
				String custom = p.getProperty(item.checksum);
				if (custom != null) {
					item.license = mapLicense(item, custom);
				}
			}
			//System.out.println("- " + name);
		}
	}
	
	 private License mapLicense(LicensedItem item, String custom) {
		 if ("Apache2".equals(custom)) return new Asf2License("Custom License Mapping");
		 if ("BSD2".equals(custom)) return new BSD2License("Custom License Mapping");
		 if ("BSD3".equals(custom)) return new BSD3License("Custom License Mapping");
		 
		UnknownLicense unknown = new UnknownLicense("Custom License");
		unknown.name = custom;
		return  unknown;
	}

	public static String convertToHex( byte[] data )
	    {
	        StringBuilder buf = new StringBuilder();
	        for ( int i = 0; i < data.length; i++ )
	        {
	            int halfbyte = ( data[i] >>> 4 ) & 0x0F;
	            int two_halfs = 0;
	            do
	            {
	                if ( ( 0 <= halfbyte ) && ( halfbyte <= 9 ) )
	                {
	                    buf.append( ( char ) ( '0' + halfbyte ) );
	                }
	                else
	                {
	                    buf.append( ( char ) ( 'a' + ( halfbyte - 10 ) ) );
	                }
	                halfbyte = data[i] & 0x0F;
	            }
	            while ( two_halfs++ < 1 );
	        }
	        return buf.toString();
	    }
}
