package com.rebaze.analytics.license;

import com.rebaze.analytics.license.provider.License;

public class BSD2License extends License {
	public BSD2License(String s) {
		super(s);
	}
	public String name = "BSD-2";
}
