package com.rebaze.analytics.license;

import com.rebaze.analytics.license.provider.License;

public class BSD3License extends License {
	public BSD3License(String s) {
		super(s);
	}

	public String name = "BSD-3";
}
